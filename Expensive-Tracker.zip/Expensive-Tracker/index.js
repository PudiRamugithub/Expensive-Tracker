let finalAmount = getAmountDetails();
// setTotalAmount();
// console.log(finalAmount.expendature);
// console.log(finalAmount.amountLeft);
let expendature = 0;
let initialAmount = 500;

displayAmountAndExpenses();
function setTotalAmount() {
  let amount = {
    expendature: 0,
    amountLeft: 500,
  };
  localStorage.setItem("Amount", JSON.stringify(amount));
  finalAmount = getAmountDetails();
  //   console.log(finalAmount.amountLeft);
}

function getAmountDetails() {
  let stringifiedAmount = localStorage.getItem("Amount");
  let parsedAmount = JSON.parse(stringifiedAmount);
  if (parsedAmount === null) {
    return [];
  } else {
    return parsedAmount;
  }
}
let expenses = getExpenseListFromLocalstorage();
let totalExpendatureAmount = document.getElementById("total-expense");
let remainingAmount = document.getElementById("amount-left");

function addExpense() {
  let expenseName = document.getElementById("expense-name");
  let expenseCost = document.getElementById("expense-cost");
  let expenseId = new Date().getTime();
  finalAmount = getAmountDetails();
  console.log(finalAmount.amountLeft);
  //   console.log(typeof(parseInt(expenseCost.value)));
  if (expenseName.value == "" || expenseCost.value == "") {
    alert("Please Ente Valid Input!");
    expenseName.value = "";
    expenseCost.value = "";
  } else {
    if (expenseCost.value <= finalAmount.amountLeft && expenseCost.value >= 1) {
      let expenseItem = {
        id: expenseId,
        name: expenseName.value,
        cost: expenseCost.value,
      };
      expenses.push(expenseItem);
      localStorage.setItem("expenseList", JSON.stringify(expenses));
      displayExpenses();

      // console.log(typeof finalAmount.expendature);
      // console.log(typeof finalAmount.amountLeft);
      // console.log(typeof expenseCost.value);

      finalAmount.amountLeft = finalAmount.amountLeft - expenseCost.value;
      finalAmount.expendature =
        finalAmount.expendature + parseInt(expenseCost.value);

      displayAmountAndExpenses();

      let amount = {
        expendature: parseInt(finalAmount.expendature),
        amountLeft: parseInt(finalAmount.amountLeft),
      };
      localStorage.setItem("Amount", JSON.stringify(amount));
      // console.log(finalAmount.expendature);
    } else {
      alert("Invalid Balance");
    }

    expenseName.value = "";
    expenseCost.value = "";
  }
}

function displayExpenses() {
  let expenseList = document.getElementById("expense-list");
  expenseList.textContent = "";
  expenses.forEach(function (expense) {
    let expenseItem = document.createElement("div");
    expenseItem.className = "expense-item";
    let itemName = document.createElement("span");
    itemName.textContent = expense.name;

    // console.log(expense);
    let itemCost = document.createElement("span");
    itemCost.textContent = `$${expense.cost}`;

    let deletBtn = document.createElement("button");
    deletBtn.classList.add("btn-delete");
    deletBtn.id = "delete-btn";
    deletBtn.textContent = "Delete";
    deletBtn.onclick = function () {
      deleteExpense(expense.id);
    };

    expenseItem.appendChild(itemName);
    expenseItem.appendChild(itemCost);
    expenseItem.appendChild(deletBtn);
    expenseList.appendChild(expenseItem);
  });
}

function getExpenseListFromLocalstorage() {
  let stringifiedExpenseList = localStorage.getItem("expenseList");
  let parsedExpenseList = JSON.parse(stringifiedExpenseList);
  if (parsedExpenseList === null) {
    return [];
  } else {
    return parsedExpenseList;
  }
}

function displayAmountAndExpenses() {
  document.getElementById("total-expense").innerText =
    finalAmount.expendature.toFixed(2);
  document.getElementById("amount-left").innerText =
    finalAmount.amountLeft.toFixed(2);
}

function deleteExpense(id) {
  const expenseToDelete = expenses.find((expense) => expense.id === id);
  finalAmount.amountLeft =
    finalAmount.amountLeft + parseInt(expenseToDelete.cost);
  finalAmount.expendature =
    finalAmount.expendature - parseInt(expenseToDelete.cost);

  displayAmountAndExpenses();

  let amount = {
    expendature: parseInt(finalAmount.expendature),
    amountLeft: parseInt(finalAmount.amountLeft),
  };
  localStorage.setItem("Amount", JSON.stringify(amount));
  // console.log(typeof expenseToDelete.cost);
  expenses = expenses.filter((expense) => expense.id != id);
  localStorage.setItem("expenseList", JSON.stringify(expenses));
  displayExpenses();
  console.log(expenses);
}

function clearAll() {
  let expenseName = document.getElementById("expense-name");
  let expenseCost = document.getElementById("expense-cost");
  expenseName.value = "";
  expenseCost.value = "";
  localStorage.removeItem("expenseList");
  expenses = [];
  setTotalAmount();
  displayExpenses();
  displayAmountAndExpenses();
}

function filterExpenses() {
  let searchTerm = document.getElementById("search-bar").value;
  // console.log(searchTerm);
  const filterExpenses = expenses.filter((expense) =>
    expense.name.toLowerCase().includes(searchTerm)
  );
  let expenseList = document.getElementById("expense-list");
  expenseList.innerText = "";
  filterExpenses.forEach((expense) => {
    let expenseItem = document.createElement("div");
    expenseItem.className = "expense-item";
    let itemName = document.createElement("span");
    itemName.textContent = expense.name;

    let itemCost = document.createElement("span");
    itemCost.textContent = `$${expense.cost}`;

    let deletBtn = document.createElement("button");
    deletBtn.classList.add("btn-delete");
    deletBtn.id = "delete-btn";
    deletBtn.textContent = "Delete";

    deletBtn.onclick = function () {
      deleteExpense(expense.id);
    };

    expenseItem.appendChild(itemName);
    expenseItem.appendChild(itemCost);
    expenseItem.appendChild(deletBtn);
    expenseList.appendChild(expenseItem);
  });
}

expenses.forEach(function (expense) {
  displayExpenses(expense);
});
